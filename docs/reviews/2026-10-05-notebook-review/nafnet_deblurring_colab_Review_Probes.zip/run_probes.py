"""Review probes for nafnet_deblurring_colab that need no torch and no checkpoint (numpy, pillow, scipy only).

P3  sample path: which pinned photographs are converted to RGB, and whether the prepare records report it.
P4  BYOD reader (read_byod + validate_records + split): compatible and incompatible archives.
P5  BYOD upload cell: what files.upload() returning {} (dialog cancelled) or two files does to the cell's code.
"""
import io, json, sys, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

repo, skdata, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(repo / "src"))
import nafnet_deblurring_pipeline.samples as S

res = {}
# ---- P3 ----
modes = {}
for name, e in S.SAMPLE_IMAGES.items():
    with Image.open(skdata / e["file"]) as im:
        modes[name] = {"mode": im.mode, "role": e["role"], "conversion_note": S.to_rgb(im)[1]}
data = S.build_sample_dataset(skdata)
keys = sorted({k for split in data.values() for r in split for k in r})
res["P3"] = {"photographs": modes,
             "greyscale_by_role": {role: [n for n, m in modes.items() if m["role"] == role and m["mode"] == "L"] for role in ("train", "test", "new-paired", "new-unpaired")},
             "record_keys": keys,
             "any_record_reports_conversion": any("conversion" in k or "note" in k for k in keys)}

# ---- P4 ----
rng = np.random.default_rng(0)
def png(h=300, w=300, mode="RGB"):
    a = rng.integers(0, 255, (h, w, 3), dtype=np.uint8)
    im = Image.fromarray(a)
    if mode != "RGB":
        im = im.convert(mode)
    b = io.BytesIO(); im.save(b, "PNG"); return b.getvalue()
def zf(name, members):
    p = out / name
    with zipfile.ZipFile(p, "w") as z:
        for k, v in members.items():
            z.writestr(k, v)
    return p
cases = {
    "paired_ok_6": {f"{d}/s{i}.png": png() for i in range(6) for d in ("sharp", "blurred")},
    "paired_wrapped_grey": {f"mine/{d}/s{i}.png": png(mode="L") for i in range(4) for d in ("sharp", "blurred")},
    "unpaired_ok_top": {f"b{i}.jpg": png() for i in range(3)},
    "paired_with_readme": {**{f"{d}/s{i}.png": png() for i in range(4) for d in ("sharp", "blurred")}, "README.txt": b"notes"},
    "unmatched": {"sharp/a.png": png(), "blurred/b.png": png(), **{f"{d}/s{i}.png": png() for i in range(4) for d in ("sharp", "blurred")}},
    "size_mismatch": {**{f"{d}/s{i}.png": png() for i in range(3) for d in ("sharp", "blurred")}, "sharp/s9.png": png(300, 300), "blurred/s9.png": png(300, 296)},
    "too_large": {**{f"{d}/s{i}.png": png() for i in range(3) for d in ("sharp", "blurred")}, "sharp/s9.png": png(1100, 300), "blurred/s9.png": png(1100, 300)},
    "three_pairs": {f"{d}/s{i}.png": png() for i in range(3) for d in ("sharp", "blurred")},
    "traversal": {"../evil.png": png(), "b.png": png()},
    "nested_extra_folder": {"blurred/x/y.png": png(), "blurred/z.png": png()},
    "small_but_valid_100px": {f"{d}/s{i}.png": png(100, 100) for i in range(4) for d in ("sharp", "blurred")},
}
p4 = {}
for name, members in cases.items():
    path = zf(name + ".zip", members)
    try:
        r = S.read_byod(path)
        row = {"accepted": True, "mode": r["mode"], "records": len(r["records"]), "conversions": r["conversions"][:3], "ignored_files": r["ignored_files"]}
        if r["mode"] == "paired":
            try:
                sp = S.split_by_source(r["records"])
                if sp is not None:
                    row["split"] = {k: len(v) for k, v in sp.items()}
            except Exception as exc:
                row["split_error"] = f"{type(exc).__name__}: {exc}"
    except Exception as exc:
        row = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"[:300]}
    p4[name] = row
res["P4"] = p4

# ---- P5: the upload branch of the BYOD cell, with files.upload() stubbed ----
nb = json.loads((repo / "tutorials/nafnet_deblurring_colab.ipynb").read_text())
cell = next("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code" and "USE_BYOD = False" in "".join(c["source"]))
src = cell.replace("USE_BYOD = False", "USE_BYOD = True")
p5 = {}
for label, uploaded in {"dialog_cancelled": {}, "two_files": {"a.zip": b"PK\x05\x06" + b"\0" * 18, "b.zip": b"x"}}.items():
    calls = []
    files_mod = type(sys)("files"); files_mod.upload = lambda u=uploaded: dict(u)
    colab = type(sys)("google.colab"); colab.files = files_mod
    google = type(sys)("google"); google.colab = colab
    sys.modules.update({"google": google, "google.colab": colab})
    ns = {"ROOT": out / f"p5_{label}", "LEARNING_RATE": 1e-4, "BATCH_SIZE": 4, "TRAINABLE_SCOPE": "decoder", "run_stage": lambda *a: calls.append([str(x) for x in a])}
    try:
        exec(compile(src, "byod_cell", "exec"), ns)
        p5[label] = {"raised": None, "run_stage_called_with": calls}
    except BaseException as exc:
        p5[label] = {"raised": f"{type(exc).__name__}: {exc}"[:200], "run_stage_called_with": calls}
res["P5_upload_branch"] = p5
(out / "results.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
